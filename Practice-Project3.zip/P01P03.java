package practice_project_assisted_practice;

public class P01P03 {
	public static void greet() {
        System.out.println("Hello! Welcome to method verification.");
    }

    public static int add(int a, int b) {
        return a + b;
    }

    public static void display(String message) {
        System.out.println("Message from display method: " + message);
    }

    public static void printNumbers(int... numbers) {
        System.out.print("Numbers: ");
        for (int num : numbers) {
            System.out.print(num + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
       
        greet();

        int sum = add(5, 3);
        System.out.println("Sum of 5 and 3: " + sum);

        display("This is a message from the display method.");

        printNumbers(1, 2, 3, 4, 5);
        printNumbers(10, 20, 30);
    }
}