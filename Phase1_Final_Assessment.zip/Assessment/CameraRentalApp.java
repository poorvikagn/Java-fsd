package Assessment;
import java.util.*;

class UserInfo {
    private String username;
    private String password;
    private double walletAmt;

    // Constructor
    public UserInfo(String username, String password, double walletAmt) {
        this.username = username;
        this.password = password;
        this.walletAmt = walletAmt;
    }

    // Getters and Setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public double getWalletAmt() {
        return walletAmt;
    }

    public void setWalletAmt(double walletAmt) {
        this.walletAmt = walletAmt;
    }

    // Method to add amount to wallet
    public void AddAmtToWallet() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Current Wallet Balance: " + walletAmt);
        System.out.print("Enter amount to add to wallet: ");
        double amount = scanner.nextDouble();
        walletAmt += amount;
        System.out.println("Amount added successfully. Updated Wallet Balance: " + walletAmt);
    }
}

class Camera {
    private int camid;
    private String brand;
    private String model;
    private float rentperday;
    private String status;

    // Constructor
    public Camera(int camid, String brand, String model, float rentperday) {
        this.camid = camid;
        this.brand = brand;
        this.model = model;
        this.rentperday = rentperday;
        this.status = "Available";
    }

    // Getters and Setters
    public int getCamid() {
        return camid;
    }

    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }

    public float getRentperday() {
        return rentperday;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}

class CameraOperations {
    private List<Camera> rentAcamera = new ArrayList<Camera>();

    // Method to add a camera
    public String AddCameras(Camera cm) {
        rentAcamera.add(cm);
        return "Camera added successfully.";
    }

    // Method to show all cameras
    public List<Camera> ShowAllCameras() {
        List<Camera> sortedList = new ArrayList<>(rentAcamera);
        Collections.sort(sortedList, Comparator.comparingInt(Camera::getCamid));
        return sortedList;
    }

    // Method to delete a camera
    public String DeleteCamera(int camid) {
        for (Camera camera : rentAcamera) {
            if (camera.getCamid() == camid) {
                if (camera.getStatus().equals("Rented")) {
                    return "Cannot delete a rented camera.";
                }
                rentAcamera.remove(camera);
                return "Camera deleted successfully.";
            }
        }
        return "Camera not found.";
    }

    // Method to rent a camera
    public void RentACamera(int camid, UserInfo user) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Available Cameras:");
        System.out.println("------------------------------------------------------------");
        System.out.printf("%-10s %-20s %-20s %-15s %-10s%n", "CamID", "Brand", "Model", "Rent/Day ($)", "Status");
        System.out.println("------------------------------------------------------------");
        for (Camera camera : rentAcamera) {
            System.out.printf("%-10d %-20s %-20s %-15.2f %-10s%n", camera.getCamid(), camera.getBrand(), camera.getModel(), camera.getRentperday(), camera.getStatus());
        }

        System.out.print("Enter the CamID of the camera you want to rent: ");
        int selectedCamid = scanner.nextInt();

        Camera selectedCamera = null;
        for (Camera camera : rentAcamera) {
            if (camera.getCamid() == selectedCamid) {
                selectedCamera = camera;
                break;
            }
        }

        if (selectedCamera == null) {
            System.out.println("Invalid CamID. Returning to main menu.");
            return;
        }

        if (selectedCamera.getStatus().equals("Rented")) {
            System.out.println("Camera is already rented. Returning to main menu.");
            return;
        }

        System.out.print("Enter rental duration (in days): ");
        int rentalDuration = scanner.nextInt();
        double totalRent = selectedCamera.getRentperday() * rentalDuration;

        if (totalRent > user.getWalletAmt()) {
            System.out.println("Insufficient balance in wallet. Please deposit the amount .....Returning to main menu.");
            return;
        }

        selectedCamera.setStatus("Rented");
        user.setWalletAmt(user.getWalletAmt() - totalRent);
        System.out.println("------------------------------------------------------------");
        System.out.println("Camera rented successfully. Amount deducted from wallet: $" + totalRent);
        System.out.println("------------------------------------------------------------");
    }
}

public class CameraRentalApp {
    public static void main(String[] args) {
    	System.out.println("***********************************************************");
    	System.out.println("            Welcome To Camera Rental App       ");
    	System.out.println("***********************************************************");
    	System.out.println("Please Enter The Login Details to Continue");
    	System.out.println("------------------------------------------------------------");
        UserInfo user = new UserInfo("admin", "admin@123", 10000.00);
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
            CameraOperations cameraOperations = new CameraOperations();

            while (true) {
                System.out.println("\nMain Menu:");
                System.out.println("1. My Camera");
                System.out.println("2. Rent A Camera");
                System.out.println("3. View All Camera");
                System.out.println("4. My Wallet");
                System.out.println("5. Exit");
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        MyCameraSubMenu(cameraOperations, scanner);
                        break;
                    case 2:
                        System.out.println("Rent A Camera Functionality:");
                        cameraOperations.RentACamera(scanner.nextInt(), user);
                        break;
                    case 3:
                        System.out.println("All Available Cameras:");
                        List<Camera> cameras = cameraOperations.ShowAllCameras();
                        PrintCameras(cameras);
                        break;
                    case 4:
                        user.AddAmtToWallet();
                        break;
                    case 5:
                        System.out.println("Exiting...");
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } else {
            System.out.println("Incorrect username/password.");
        }
    }

    private static void MyCameraSubMenu(CameraOperations cameraOperations, Scanner scanner) {
        while (true) {
            System.out.println("\nMy Camera Sub Menu:");
            System.out.println("1. Add Camera");
            System.out.println("2. Remove Camera");
            System.out.println("3. View All Camera");
            System.out.println("4. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    AddCameraFunctionality(cameraOperations, scanner);
                    break;
                case 2:
                    RemoveCameraFunctionality(cameraOperations, scanner);
                    break;
                case 3:
                    System.out.println("All Available Cameras:");
                    List<Camera> cameras = cameraOperations.ShowAllCameras();
                    PrintCameras(cameras);
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void AddCameraFunctionality(CameraOperations cameraOperations, Scanner scanner) {
        System.out.print("Enter Brand:");
        String brand = scanner.next();
        System.out.print("Enter Model:");
        String model = scanner.next();
        System.out.print("Enter Rent per Day: ");
        float rentperday = scanner.nextFloat();

        Camera newCamera = new Camera(cameraOperations.ShowAllCameras().size() + 1, brand, model, rentperday);
        String result = cameraOperations.AddCameras(newCamera);
        System.out.println(result);
    }

    private static void RemoveCameraFunctionality(CameraOperations cameraOperations, Scanner scanner) {
        System.out.print("Enter CamID of camera to remove: ");
        int camid = scanner.nextInt();
        String result = cameraOperations.DeleteCamera(camid);
        System.out.println(result);
    }

    private static void PrintCameras(List<Camera> cameras) {
        if (cameras.isEmpty()) {
            System.out.println("No cameras available.");
            return;
        }
        System.out.println("--------------------------------------------------------------------------------------");
        System.out.printf("%-10s %-20s %-20s %-15s %-10s%n", "CamID", "Brand", "Model", "Rent/Day ($)", "Status");
        System.out.println("--------------------------------------------------------------------------------------");
        for (Camera camera : cameras) {
            System.out.printf("%-10d %-20s %-20s %-15.2f %-10s%n", camera.getCamid(), camera.getBrand(), camera.getModel(), camera.getRentperday(), camera.getStatus());
        }
    }
}
