package practice_project_assisted_practice;

import java.util.Stack;
public class P01P27 {

	    public static void main(String[] args) {
	        Stack<Integer> stack = new Stack<>();

	        pushElement(stack, 5);
	        pushElement(stack, 10);
	        pushElement(stack, 15);
	        pushElement(stack, 20);

	        System.out.println("Stack after insertion:");
	        displayStack(stack);

	        popElement(stack);
	        popElement(stack);

	        System.out.println("\nStack after removal:");
	        displayStack(stack);
	    }

	    static void pushElement(Stack<Integer> stack, int element) {
	        stack.push(element);
	        System.out.println("Pushed element: " + element);
	    }

	    static void popElement(Stack<Integer> stack) {
	        if (stack.isEmpty()) {
	            System.out.println("Stack is empty. Cannot pop element.");
	            return;
	        }
	        int poppedElement = stack.pop();
	        System.out.println("Popped element: " + poppedElement);
	    }

	    static void displayStack(Stack<Integer> stack) {
	        if (stack.isEmpty()) {
	            System.out.println("Stack is empty");
	            return;
	        }
	        System.out.println("Elements of the stack:");
	        for (int i = stack.size() - 1; i >= 0; i--) {
	            System.out.println(stack.get(i));
	        }
	    }
	}
