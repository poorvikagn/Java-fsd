package practice_project_assisted_practice;

import java.util.Scanner;

class MessagePrinter {
	     public synchronized void printMessage(String message) {
	        System.out.print("[" + message + "] ");
	        try {
	            Thread.sleep(1000); // Simulating some processing time
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	        System.out.println("Printed by: " + Thread.currentThread().getName());
	    }
	}

	class PrintThread extends Thread {
	    private String message;
	    private MessagePrinter printer;

	    public PrintThread(String message, MessagePrinter printer) {
	        this.message = message;
	        this.printer = printer;
	    }

	    public void run() {
	        printer.printMessage(message);
	    }
	}

	public class P01P13 {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        MessagePrinter printer = new MessagePrinter();

	        System.out.print("Enter a message to print: ");
	        String message = scanner.nextLine();

	        Thread thread1 = new PrintThread(message, printer);
	        Thread thread2 = new PrintThread(message, printer);

	        thread1.start();
	        thread2.start();

	        scanner.close();
	    }
	}
