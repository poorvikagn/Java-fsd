package practice_project_assisted_practice;

public class P01P01 {

	    public static void main(String[] args) {
	        
	        int intValue = 100;
	        long longValue = intValue; 
	        float floatValue = 3.14f;
	        double doubleValue = floatValue; 
	        
	        System.out.println("Implicit Type Casting:");
	        System.out.println("int value: " + intValue);
	        System.out.println("long value: " + longValue);
	        System.out.println("float value: " + floatValue);
	        System.out.println("double value: " + doubleValue);

	        double bigValue = 9876.54321;
	        int smallValue = (int) bigValue; 

	        long veryBigIntValue = 1234567890123456789L;
	        int veryBigIntCastedValue = (int) veryBigIntValue; 

	        System.out.println("\nExplicit Type Casting:");
	        System.out.println("double value: " + bigValue);
	        System.out.println("int value after explicit casting: " + smallValue);
	        System.out.println("long value: " + veryBigIntValue);
	        System.out.println("int value after explicit casting: " + veryBigIntCastedValue);
	    }
	}
