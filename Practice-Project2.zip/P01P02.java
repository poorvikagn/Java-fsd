package practice_project_assisted_practice;

public class P01P02{
private int privateVariable = 10;
int defaultVariable = 20;
protected int protectedVariable = 30;
public int publicVariable = 40;

private void privateMethod() {
    System.out.println("Private Method");
}

void defaultMethod() {
    System.out.println("Default Method");
}

protected void protectedMethod() {
    System.out.println("Protected Method");
}

public void publicMethod() {
    System.out.println("Public Method");
}

public static void main(String[] args) {
	P01P02 obj = new P01P02();

    System.out.println("Private Variable: " + obj.privateVariable);
    System.out.println("Default Variable: " + obj.defaultVariable);
    System.out.println("Protected Variable: " + obj.protectedVariable);
    System.out.println("Public Variable: " + obj.publicVariable);

    obj.privateMethod();
    obj.defaultMethod();
    obj.protectedMethod();
    obj.publicMethod();
}
}
