package practice_project_assisted_practice;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.HashSet;
import java.util.Set;

public class P01P05 {
    public static void main(String[] args) {
        
        verifyArrayList();

        verifyLinkedList();

        verifyHashSet();
    }

    private static void verifyArrayList() {
        System.out.println("Verifying ArrayList implementation:");
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("Apple");
        arrayList.add("Banana");
        arrayList.add("Orange");

        System.out.println("ArrayList contents:");
        for (String item : arrayList) {
            System.out.println(item);
        }
        System.out.println();
    }

    private static void verifyLinkedList() {
        System.out.println("Verifying LinkedList implementation:");
        LinkedList<Integer> linkedList = new LinkedList<>();
        linkedList.add(10);
        linkedList.add(20);
        linkedList.add(30);

        System.out.println("LinkedList contents:");
        for (int item : linkedList) {
            System.out.println(item);
        }
        System.out.println();
    }

    private static void verifyHashSet() {
        System.out.println("Verifying HashSet implementation:");
        Set<Character> hashSet = new HashSet<>();
        hashSet.add('A');
        hashSet.add('B');
        hashSet.add('C');

        System.out.println("HashSet contents:");
        for (char item : hashSet) {
            System.out.println(item);
        }
        System.out.println();
    }
}