package practice_project_assisted_practice;

import java.util.Arrays;
public class P01P21 {

    public static void main(String[] args) {
        int[] arr = { 10, 3, 9, 14, 16, 21, 1, 4}; 
        
        int fourthSmallest = findFourthSmallest(arr);
        
        System.out.println("The fourth smallest element in the list is: " + fourthSmallest);
    }
    
    static int findFourthSmallest(int[] arr) {
        if (arr.length < 4) {
            System.out.println("List does not have enough elements.");
            return -1;
        }
        
        Arrays.sort(arr); 
        
        return arr[3]; 
    }
}