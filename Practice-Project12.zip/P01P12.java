package practice_project_assisted_practice;

import java.util.Scanner;

class SleepThread extends Thread {
    private int sleepTime;

    public SleepThread(int sleepTime) {
        this.sleepTime = sleepTime;
    }

    public void run() {
    	System.out.println("-------------------------------");
        System.out.println("SleepThread is starting.");
        try {
            Thread.sleep(sleepTime);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("SleepThread is done sleeping.");
    }
}

class WaitThread extends Thread {
    private Object lock;

    public WaitThread(Object lock) {
        this.lock = lock;
    }

    public void run() {
        System.out.println("WaitThread is starting.");
        synchronized (lock) {
            try {
                lock.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("WaitThread is done waiting.");
    }
}

public class P01P12  {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter sleep time for SleepThread (in milliseconds): ");
        int sleepTime = scanner.nextInt();
        System.out.println("-------------------------------");
        SleepThread sleepThread = new SleepThread(sleepTime);
        sleepThread.start();

        System.out.println("Press Enter to start WaitThread...");
        scanner.nextLine();
        scanner.nextLine(); 
        System.out.println("-------------------------------");
        Object lock = new Object();
        WaitThread waitThread = new WaitThread(lock);
        waitThread.start();

        try {
            Thread.sleep(sleepTime / 2);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        synchronized (lock) {
            lock.notify();
        }

        scanner.close();
    }
}