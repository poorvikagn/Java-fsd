package practice_project_assisted_practice;

import java.util.Arrays;

public class P01P31{
    public static void main(String[] args) {
        int[] array = { 23, 38, 56, 72, 91};
        int target = 91;
        int result = exponentialSearch(array, target);
        if (result == -1) {
            System.out.println("Element not found in the array.");
        } else {
            System.out.println("Element found at index: " + result);
        }
    }

    public static int exponentialSearch(int[] array, int target) {
        if (array[0] == target) {
            return 0; 
        }

        int i = 1;
        while (i < array.length && array[i] <= target) {
            i *= 2;
        }

        return Arrays.binarySearch(array, i / 2, Math.min(i, array.length), target);
    }
}