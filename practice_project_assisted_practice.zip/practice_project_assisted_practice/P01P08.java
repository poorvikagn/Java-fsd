package practice_project_assisted_practice;

public class P01P08 {

	  public static void main(String[] args) {
	       
	        String str = "Welcome!";

	        StringBuffer stringBuffer = new StringBuffer(str);

	        StringBuilder stringBuilder = new StringBuilder(str);

	        System.out.println("Original String: " + str);
	        System.out.println("String to StringBuffer: " + stringBuffer);
	        System.out.println("String to StringBuilder: " + stringBuilder);
	    }
	}
