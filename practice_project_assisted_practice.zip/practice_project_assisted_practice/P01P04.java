package practice_project_assisted_practice;

public class P01P04 {
	    private int value;

	    public P01P04() {
	        System.out.println("Default Constructor called.");
	        this.value = 0;
	    }

	    public P01P04(int value) {
	        System.out.println("Parameterized Constructor called.");
	        this.value = value;
	    }

	    public P01P04(P01P04 obj) {
	        System.out.println("Copy Constructor called.");
	        this.value = obj.value;
	    }

	    public void display() {
	        System.out.println("Value: " + value);
	    }

	    public static void main(String[] args) {
	    	P01P04 obj1 = new P01P04(); // Default Constructor
	    	P01P04 obj2 = new P01P04(10); // Parameterized Constructor
	    	P01P04 obj3 = new P01P04(obj2); // Copy Constructor

	        System.out.println("\nValues of objects:");
	        obj1.display();
	        obj2.display();
	        obj3.display();
	    }
	}