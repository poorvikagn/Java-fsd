package practice_project_assisted_practice;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class P01P10 {
	
	    public static void main(String[] args) {
	       
	        String text1 = "The quick brown fox jumps over the lazy dog";
	        String text2 = "B4U";
	        String text3 = "Hello, world!";

	        String pattern1 = "brown";
	        String pattern2 = "\\a+";
	        String pattern3 = "\\w+";

	        verifyRegex(text1, pattern1);
	        verifyRegex(text2, pattern2);
	        verifyRegex(text3, pattern3);
	    }

	    private static void verifyRegex(String text, String regex) {
	        Pattern pattern = Pattern.compile(regex);
	        Matcher matcher = pattern.matcher(text);

	        if (matcher.find()) {
	            System.out.println("Pattern \"" + regex + "\" found in text: " + text);
	        } else {
	            System.out.println("Pattern \"" + regex + "\" not found in text: " + text);
	        }
	    }
	}