package practice_project_assisted_practice;

public class P01P07 {
	   
	    class InnerClass {
	        public void display() {
	            System.out.println("This is the inner class method");
	        }
	    }
	    
	    public static void main(String[] args) {
	        
	    	P01P07 outerObj = new P01P07();
	        
	        InnerClass innerObj = outerObj.new InnerClass();
	        innerObj.display();
	        
	        P01P07.InnerClass innerObj2 = outerObj.new InnerClass();
	        innerObj2.display();
	    }
	}