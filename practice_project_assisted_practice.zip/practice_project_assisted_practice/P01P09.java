package practice_project_assisted_practice;

public class P01P09 {
    public static void main(String[] args) {
	        
	        int[] array = {1, 2, 3, 4, 5};

	        System.out.println("Original Array:");
	        displayArray(array);

	        for (int i = 0; i < array.length; i++) {
	            array[i] *= 2;
	        }

	        System.out.println("\nModified Array (doubling each element):");
	        displayArray(array);
	    }

	    private static void displayArray(int[] array) {
	        for (int i = 0; i < array.length; i++) {
	            System.out.print(array[i] + " ");
	        }
	        System.out.println();
	    }
	}
