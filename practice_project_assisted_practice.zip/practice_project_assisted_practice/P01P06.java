package practice_project_assisted_practice;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.LinkedHashMap;

public class P01P06 {
	    public static void main(String[] args) {
	        
	        verifyHashMap();

	        verifyTreeMap();

	        verifyLinkedHashMap();
	    }

	    private static void verifyHashMap() {
	        System.out.println("Verifying HashMap implementation:");
	        Map<String, Integer> hashMap = new HashMap<>();
	        hashMap.put("apple", 10);
	        hashMap.put("banana", 20);
	        hashMap.put("orange", 30);

	        System.out.println("HashMap contents:");
	        for (Map.Entry<String, Integer> entry : hashMap.entrySet()) {
	            System.out.println(entry.getKey() + " : " + entry.getValue());
	        }
	        System.out.println();
	    }

	    private static void verifyTreeMap() {
	        System.out.println("Verifying TreeMap implementation:");
	        Map<String, Integer> treeMap = new TreeMap<>();
	        treeMap.put("apple", 10);
	        treeMap.put("banana", 20);
	        treeMap.put("orange", 30);

	        System.out.println("TreeMap contents:");
	        for (Map.Entry<String, Integer> entry : treeMap.entrySet()) {
	            System.out.println(entry.getKey() + " : " + entry.getValue());
	        }
	        System.out.println();
	    }

	    private static void verifyLinkedHashMap() {
	        System.out.println("Verifying LinkedHashMap implementation:");
	        Map<String, Integer> linkedHashMap = new LinkedHashMap<>();
	        linkedHashMap.put("apple", 10);
	        linkedHashMap.put("banana", 20);
	        linkedHashMap.put("orange", 30);

	        System.out.println("LinkedHashMap contents:");
	        for (Map.Entry<String, Integer> entry : linkedHashMap.entrySet()) {
	            System.out.println(entry.getKey() + " : " + entry.getValue());
	        }
	        System.out.println();
	    }
	}